from gamefield_schema_layer import *
from typing import List, Union
import sys

#########################################################################################
# TODO: Dividir este archivo en 3, convertirlo en 3 capas distintas
#########################################################################################


##########################################################################################
######################## DEFINITIONS AND CONTROLLERS #####################################


class UnsatisfiedPolicy(BaseModel):
    commandName: str
    message: str


class AppliedPolicy(BaseModel):
    isSatisfied: bool
    policyError: Optional[UnsatisfiedPolicy]


class PoliciesContainer:
    def _policies_list(self):
        return [method for method in dir(self) if method.startswith("_") is False]


######################## END OF DEFINITIONS AND CONTROLLERS BLOCK ######################
########################################################################################

####################### POLICIES EVALUETION CLASESS ####################################

# TODO: LINK HERE THE POLICIES FOR EVERY ENABLED COMMAND


class CreateGameFieldPolicies(PoliciesContainer):
    def dummy_policy(command: Command) -> AppliedPolicy:
        return GameFieldPolicies.a_dummy_policy(command)


# TODO: PUT HERE THE EVALUATION FOR EVERY POLICY


class GameFieldPolicies:
    def a_dummy_policy(command: Command) -> AppliedPolicy:
        unsatisfiedPolicie = UnsatisfiedPolicy(
            **{"message": "Dummy Error Okay", "commandName": command.commandName}
        )
        appliedPolicyPayload = {"isSatisfied": False, "policyError": unsatisfiedPolicie}
        return AppliedPolicy(**appliedPolicyPayload)


##########################################################################################
##########################################################################################
####################### POLICY PROCESSOR CLASS ###########################################

class PolicyProcessor:
    def __apply_policy(
        policy,  # (command: Command) -> AppliedPolicy
        command: Command,
        appliedPolicies: List[AppliedPolicy],
    ) -> List[AppliedPolicy]:
        appliedPolicy = policy(command)
        appliedPolicies.append(appliedPolicy)
        return appliedPolicies

    def __applied_policies_for_command(
        command: Command,
        policyClass: PoliciesContainer,
    ) -> Union[bool, Optional[List[UnsatisfiedPolicy]]]:
        policiesNamesList = policyClass._policies_list(policyClass)
        appliedPolicies = []
        for policy in policiesNamesList:
            appliedPolices = PolicyProcessor.__apply_policy(
                getattr(policyClass, policy),
                command,
                appliedPolicies,
            )
        isEverythingApproved = all(list(map(lambda x: x.isSatisfied, appliedPolices)))
        if isEverythingApproved:
            return True, None
        else:
            unsatisfiedPolicies = list(map(lambda x: x.policyError, appliedPolices))
            return False, unsatisfiedPolicies

    def apply_policies_by_command_type(
        command: Command,
    ) -> Union[bool, Optional[List[UnsatisfiedPolicy]]]:
        listOfCommands = list(EnabledCommand)
        for name in listOfCommands:
            if (
                name == command.commandName
            ):  # TODO insecure code here.. well, everywhere
                policyClass = getattr(sys.modules[__name__], "{}Policies".format(name))
                if policyClass == None:
                    print(
                        "ERROR: Policies not registered for this command: {}".format(
                            command.commandName
                        )
                    )
                    return False, [
                        UnsatisfiedPolicy(
                            **{
                                "message": "ERROR: Policies not registered for this command",
                                "commandName": command.commandName,
                            }
                        )
                    ]
                return PolicyProcessor.__applied_policies_for_command(
                    command, policyClass
                )
        print(
            "ERROR: Policies not processed for command: {}".format(command.commandName)
        )
        return False, None
